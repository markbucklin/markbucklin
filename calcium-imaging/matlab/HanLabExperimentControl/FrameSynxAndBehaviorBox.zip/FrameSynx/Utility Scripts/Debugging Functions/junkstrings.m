MatlabCompatibleCamera < Camera
c = Camera;
a = Camera();
Camera.method
@Camera.withat

b = cameraObj
a = DalsaCamera
cap = Camera
