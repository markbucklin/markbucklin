This folder contains revised versions of MATLAB built-in functions that
have unresolved issues for these layouts. As the issues are fixed these 
functions will be removed.