The file 'alignImages.m' contains the entry function alignImages(.....)
The input images should be in grayscale and converted to double type. 
For futher help please refer to the documentation within the code files.


