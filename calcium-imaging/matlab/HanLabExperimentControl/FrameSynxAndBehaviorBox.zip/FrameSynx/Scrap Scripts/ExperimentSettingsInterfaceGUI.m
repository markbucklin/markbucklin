classdef ExperimentSettingsInterfaceGUI < GUI
	
	
	
	
	
	
	
	properties
	end
	
	
	
	
	
	
	events
		
	end
	
	
	
	
	
	
	methods
		function obj = ExperimentSettingsInterfaceGUI(mainobj)
			obj = obj@GUI(mainobj);
		end
	end
	
	
	
	
	
	
	
	
end