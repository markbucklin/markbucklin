function eventListenDisplay(src,evnt)

fprintf('%s: %s\n',class(src),  evnt.EventName)
