obj = TouchDisplay;
setup(obj);
io = NiDaqInterface;
setup(io)

