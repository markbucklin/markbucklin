/* **************************************************************** *

	dcamapix.h:	June 21, 2013

 * **************************************************************** */

#ifndef	_INCLUDE_DCAMAPIX_H_
#define	_INCLUDE_DCAMAPIX_H_

// ****************************************************************

/*
	From DCAM-API Version 3.2, this header is not necessary to include in caller source file.
	The all definitions go into dcamapi.h
*/

// ****************************************************************

#endif /* _INCLUDE_DCAMAPIX_H_	*/
