/* ccDefine.h

	From DCAM-API Version 3.0, this header is not necessary to include in caller source file.
	The all definitions go into dcamapi.h
*/
