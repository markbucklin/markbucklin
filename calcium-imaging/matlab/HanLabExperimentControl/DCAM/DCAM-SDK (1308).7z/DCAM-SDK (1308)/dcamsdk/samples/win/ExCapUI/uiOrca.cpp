// uiOrca.cpp
//

#include "stdafx.h"
#include "excapui.h"
#include "uiOrca.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

EXCAPUIERR uiOrca_query_supportdialog_setup( const DCAMSTRINGS& strs )
{
	return EXCAPUIERR_UNKNOWNCAMERA;
}

EXCAPUIERR uiOrca_modal_dialog_setup( HDCAM hdcam, const DCAMSTRINGS& strs )
{
	return EXCAPUIERR_UNKNOWNCAMERA;
}
