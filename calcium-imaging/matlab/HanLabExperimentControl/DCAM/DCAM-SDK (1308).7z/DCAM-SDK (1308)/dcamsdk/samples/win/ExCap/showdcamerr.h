// showdcamerr.h
//

void show_dcamerrorbox( HDCAM hdcam, const char* function );
