// mechctrl.h

BOOL dcamex_querypropertyvalue_mechanicalshutter( HDCAM hdcam, int32 mode );
BOOL dcamex_getpropertyvalue_mechanicalshutter( HDCAM hdcam, int32& mode );
BOOL dcamex_setpropertyvalue_mechanicalshutter( HDCAM hdcam, int32  mode );

