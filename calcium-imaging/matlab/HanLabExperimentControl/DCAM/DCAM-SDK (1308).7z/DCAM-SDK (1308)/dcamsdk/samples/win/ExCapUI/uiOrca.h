// uiOrca.h
//

EXCAPUIERR	uiOrca_query_supportdialog_setup( const DCAMSTRINGS& strs );
EXCAPUIERR	uiOrca_modal_dialog_setup( HDCAM hdcam, const DCAMSTRINGS& strs );
