// uiXline.h
//

EXCAPUIERR	uiXline_query_supportdialog_setup( const DCAMSTRINGS& strs );
EXCAPUIERR	uiXline_modal_dialog_setup( HDCAM hdcam, const DCAMSTRINGS& strs );
