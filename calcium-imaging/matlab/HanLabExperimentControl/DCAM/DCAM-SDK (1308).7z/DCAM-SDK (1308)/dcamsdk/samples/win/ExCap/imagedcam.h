// imagedcam.h
//

image* new_imagedcam( HDCAM h );
