function parentPkgName = getParentPackage()


% className = mfilename('class');
% fullPkgName = strsplit(className,'.');

callerPath = evalin('caller', 'mfilename(''fullpath'')');
fullPkgName = regexp(callerPath, '\+(\w)+', 'tokens');
parentPkgName = sprintf('%s.', fullPkgName{1:end-1});


% parentPkgName = [ sprintf('%s.', fullPkgName{1:end-1}), '*'];
% import(parentPkgName)



