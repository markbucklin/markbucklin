function m = stackMax(x)

m = max(x,[],3);
