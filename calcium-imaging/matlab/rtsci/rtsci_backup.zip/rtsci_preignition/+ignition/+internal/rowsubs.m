function subs = rowsubs(numRows)

subs = reshape(1:numRows, numRows, 1);
