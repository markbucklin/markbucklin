function m = stackMean(x)

m = mean(x,3);
