function subs = chansubs(numChannels)

subs = reshape(1:numChannels, 1, 1, 1, numChannels);
