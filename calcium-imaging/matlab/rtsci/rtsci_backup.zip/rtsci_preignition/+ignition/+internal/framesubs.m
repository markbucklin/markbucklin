function subs = framesubs(numFrames)

subs = reshape(1:numFrames, 1, 1, numFrames);
