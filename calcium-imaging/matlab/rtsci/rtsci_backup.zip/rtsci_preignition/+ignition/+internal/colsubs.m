function subs = colsubs(numCols)

subs = reshape(1:numCols, 1, numCols);
