function m = stackMin(x)

m = min(x,[],3);
