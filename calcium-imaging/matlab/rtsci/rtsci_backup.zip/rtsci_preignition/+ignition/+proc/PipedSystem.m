classdef (CaseInsensitiveProperties, TruncatedProperties) PipedSystem < ignition.System
	
	
	
	
	properties (SetAccess = ?ignition.System)
		InputDataType
		InputRange
		OutputDataType
		OutputRange
		FrameSize
		MaxFramesPerStep
	end
	properties (SetAccess = ?ignition.System, Nontunable)
		GpuKernelCompanionFcn @ignition.proc.gpu.GpuKernelCompanionFunctionWrapper
	end
	
	
	
	methods (Access = ?ignition.System)
		function addCompanionFcn(obj, fcnName)
			
		end
	end
	methods (Access = ?ignition.System)
		function F = checkInput(obj, F)
			
			% INPUT DIMENSIONS
			if isempty(obj.FrameSize)
				[numRows, numCols, numChans, numFrames] = size(F);
				obj.FrameSize = [numRows numCols numChans];
			end
			if ~isempty(obj.MaxFramesPerStep)
				obj.MaxFramesPerStep = numFrames;
			else
				obj.MaxFramesPerStep = max( numFrames, obj.MaxFramesPerStep); %TODO
			end
			
			% DATA-TYPE
			obj.InputDataType = getClass(obj, F);
			
			% RANGE
			fMin = onCpu(obj, min(F(:)));
			fMax = onCpu(obj, max(F(:)));
			if ~isempty(obj.InputRange)
				curMin = obj.InputRange(1);
				curMax = obj.InputRange(2);
				obj.InputRange = [ min(fMin, curMin) , max(fMax, curMax) ];
			else
				obj.InputRange = [ fMin, fMax ];
			end
			
			% 			if ismethod(obj, 'processData')
			% 				fprintf('superclass processdata call from checkInput\n')
			% 				output = processData(obj, data);
			% 				obj.OutputDataType = getClass(obj, output);
			
			% GPU
			if isempty(obj.UseGpu)
				obj.UseGpu = isa(F,'gpuArray');
			end
			if obj.UseGpu
				if ~isa(F, 'gpuArray')
					F = gpuArray(F);
				end
				% TODO: check if exists on current gpu -> for multigpu
				
			end
			
			
			% 			tuneLimitScalingFactors(obj, data);
			
			
		end				
		function F = checkOutput(obj, F)
			
			% DATA-TYPE
			if isempty(obj.OutputDataType)
				obj.OutputDataType = getClass(obj, F);
			end
			
			% RANGE
			fMin = onCpu(obj, min(F(:)));
			fMax = onCpu(obj, max(F(:)));
			if ~isempty(obj.OutputRange)
				curMin = obj.OutputRange(1);
				curMax = obj.OutputRange(2);
				obj.OutputRange = [ min(fMin, curMin) , max(fMax, curMax) ];
			else
				obj.OutputRange = [ fMin, fMax ];
			end
			
			
		end
	end	
	methods (Access = protected)
		function setupImpl(obj, F)
			% Called by Setup(obj, F) or on first call to Step(obj, F)
			
			% INITIALIZATION (STANDARD)			
			F = checkInput(obj, F);
			initialize(obj)		
			
			
		end
		function resetImpl(obj)
			
		end
		function releaseImpl(obj)
			fetchPropsFromGpu(obj)
		end
	end
	
	
	
	
	
end







