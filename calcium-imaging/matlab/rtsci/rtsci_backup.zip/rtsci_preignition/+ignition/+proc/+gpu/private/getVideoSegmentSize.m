function [numRows, numCols, numChannels, numFrames] = getVideoSegmentSize(F)

[numRows,numCols,numChannels, numFrames] = size(F);
