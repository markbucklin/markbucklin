

!"%ProgramW6432%\NVIDIA Corporation\NVSMI\nvidia-smi.exe" -h
