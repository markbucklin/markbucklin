clear
close all
dev = gpuDevice;
dev.reset
clear all
clear classes
clc
