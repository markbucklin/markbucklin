version -java
feature getpid

% md = feature('dumpmem')

% force garbage collection
java.lang.System.gc
feature('GpuAllocPoolSizeKb',0)


ci = getcallinfo(which('ignition.System'))
o = mtree('ignition.System')
% matlab.internal.getcode

